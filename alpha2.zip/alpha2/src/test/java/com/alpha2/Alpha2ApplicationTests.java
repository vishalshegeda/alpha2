package com.alpha2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Alpha2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
